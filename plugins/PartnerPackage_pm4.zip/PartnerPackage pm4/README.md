A partner packages plugin for your hcf server.

# Commands
- /pp edit (Set items in partner package)
- /pp items (See items in partner packages)
- /pp give (Give partner packages)
