<?php

namespace itz;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\ItemIds;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class Main extends PluginBase{
  
public function onEnable() : void {
  $this->saveDefaultConfig();
}

  
  public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool{
    if(strtolower($command->getName()) === "votar"){
      if(!$sender instanceof Player){
        $sender->sendMessage(TF::RED . "Este comando solo se puede ejecutar en el juego");
        return true;
      }
      
      if($this->hasCooldown($sender)){
        $sender->sendMessage(TF::RED . "Todavía no puedes votar. Intenta de nuevo más tarde.");
        return true;
      }
      
      $this->openVoteMenu($sender);
      
      return true;
    }
    
    return false;
  }
  
  public function onVote(Player $player, int $vote){
    $config = new Config($this->getDataFolder() . "votes.yml", Config::YAML);
    $playerName = $player->getName();
    
    if($config->exists($playerName)){
      $player->sendMessage(TF::RED . "Ya has votado. No puedes votar de nuevo.");
      return;
    }
    
    $config->set($playerName, $vote);
    $config->save();
    
    $player->sendMessage(TF::GREEN . "Gracias por votar. Has ganado un diamante.");
    $player->getInventory()->addItem(ItemIds::DIAMOND, 100);
    
    $this->setCooldown($player);
  }
  
  public function openVoteMenu(Player $player){
    $menu = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm([$this, "onVote"]);
    $menu->setTitle("Votación");
    $menu->setContent("Por favor, selecciona una de las dos opciones:");
    $menu->addButton("ItzAngel");
    $menu->addButton("JisusFive");
    $menu->sendToPlayer($player);
  }
  
  public function hasCooldown(Player $player) : bool{
    $config = new Config($this->getDataFolder() . "cooldowns.yml", Config::YAML);
    $playerName = $player->getName();
    $lastVote = $config->get($playerName, 0);
    return time() - $lastVote < 60;
  }
  
  public function setCooldown(Player $player){
    $config = new Config($this->getDataFolder() . "cooldowns.yml", Config::YAML);
    $playerName = $player->getName();
    $config->set($playerName, time());
    $config->save();
  }
  
}
