<?php

namespace ErikPDev\AdvanceDeaths\leaderboards\events;


use pocketmine\event\Event;

class leaderboardClose extends Event {

}